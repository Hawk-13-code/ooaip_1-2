package org.example;

import java.util.HashMap;

public interface Parse {
    void parse(String line, HashMap hashMap);
}
